

== Changelog ==

= 23 December 2019 =
* fixing various template-first theme issues.

= 18 December 2019 =
* add styling for Blog Posts block. https://github.com/Automattic/themes/pull/1710

= 31 October 2019 =
* Allow Separator Block color options.
* Update to version 1.3.0

= 28 October 2019 =
* Regenerate annotations for template-first themes

= 25 October 2019 =
* Update the Headstart file with accessibility changes

= 21 October 2019 =
* Update Headstart
* Add Global Styles support

= 4 October 2019 =
* Add auto-loading-homepage tag to stylesheet, minor version bump

= 28 August 2019 =
* Hever 1.1.1: RTL fix and recompilation of child themes.

= 27 August 2019 =
* Hever 1.1.0: Updates version and dependancies.

= 20 August 2019 =
* Recompile varia styles to fix nested separator block widths.

= 19 August 2019 =
* Refactor responsive logic to better support nested blocks with varying widths

= 2 August 2019 =
* Add site-branding template part & rework header grid
* Add style for Jetpack Subscription Form block
* Update Headstart annotations with content from the demo site

= 1 August 2019 =
* Add Headstart annotations
* Site Logo: Increase padding bottom
* Update screenshot
* Increase priority of `hever_setup()`
* Update editor font sizes
* Create a GlotPress Project

= 31 July 2019 =
* Initial import of the theme from wprog
